-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 07. Jan 2023 um 02:04
-- Server-Version: 10.4.24-MariaDB
-- PHP-Version: 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Datenbank: `getraenkehandel2`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `artikel`
--

CREATE TABLE `artikel` (
  `ArtikelID` int(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `artikelNummer` int(11) NOT NULL,
  `inhalt` float NOT NULL,
  `preis` float NOT NULL,
  `onStock` varchar(8) NOT NULL,
  `path` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `artikel`
--

INSERT INTO `artikel` (`ArtikelID`, `name`, `artikelNummer`, `inhalt`, `preis`, `onStock`, `path`) VALUES
(1, 'Coca Cöla Original 1l', 1000, 1, 1.5, '0', '../images/coca_cola.png'),
(2, 'Fanta 1l', 1001, 1, 1.5, '10', '../images/fanta.png'),
(3, 'Sprite 1l', 1002, 1, 1.5, '20', '../images/sprite.png'),
(4, 'Mezzo Mix 1l', 1003, 1, 1.5, '14', '../images/mezzo_mix.png'),
(5, 'Red Bull', 1004, 0.25, 1.69, '48', '../images/red_bull.png'),
(6, 'Arizona White Tea', 1005, 0.5, 1.89, '24', '../images/arizona_white_tea.png'),
(7, 'Arizona Pomegranete', 1006, 0.5, 1.89, '18', '../images/arizona_pomegranete.png'),
(8, 'Arizona Fruit Punch', 1007, 0.5, 1.89, '30', '../images/arizona_fruit_punch.png'),
(9, 'Vio Medium 0.5l', 1008, 0.5, 1.09, '48', '../images/vio_mineralwasser.png'),
(10, 'Vio Still 0.5l', 1009, 0.5, 1.09, '48', '../images/vio_still.png');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bestellitem`
--

CREATE TABLE `bestellitem` (
  `BestellItemID` int(64) NOT NULL,
  `BestellID` int(64) NOT NULL,
  `ArtikelID` int(64) NOT NULL,
  `Menge` int(64) NOT NULL,
  `PositionsPreis` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `bestellitem`
--

INSERT INTO `bestellitem` (`BestellItemID`, `BestellID`, `ArtikelID`, `Menge`, `PositionsPreis`) VALUES
(107, 47, 1, 14, 16.8),
(108, 47, 2, 15, 18),
(109, 47, 3, 4, 6),
(110, 47, 4, 2, 3),
(111, 47, 5, 16, 21.63),
(112, 47, 6, 5, 8.51),
(113, 47, 7, 1, 1.89),
(114, 48, 1, 30, 36),
(115, 49, 1, 14, 16.8);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bestellung`
--

CREATE TABLE `bestellung` (
  `BestellID` int(64) NOT NULL,
  `UserID` int(64) NOT NULL,
  `Gesamtpreis` double NOT NULL,
  `Versandpreis` double NOT NULL,
  `Versandart` varchar(128) NOT NULL,
  `discountID` int(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `bestellung`
--

INSERT INTO `bestellung` (`BestellID`, `UserID`, `Gesamtpreis`, `Versandpreis`, `Versandart`, `discountID`) VALUES
(47, 5, 75.83, 6, 'DPD', 0),
(48, 5, 36, 15, 'DHL', 0),
(49, 5, 16.8, 6, 'DPD', 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `discount`
--

CREATE TABLE `discount` (
  `discountID` int(11) NOT NULL,
  `discountName` varchar(8) NOT NULL,
  `discountValue` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `discount`
--

INSERT INTO `discount` (`discountID`, `discountName`, `discountValue`) VALUES
(1, 'NEWYEAR1', 0.1),
(2, 'CHRIST20', 0.2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `kunde`
--

CREATE TABLE `kunde` (
  `UserID` int(64) NOT NULL,
  `vorname` varchar(64) NOT NULL,
  `nachname` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `password` varchar(255) NOT NULL,
  `lastLogin` varchar(64) NOT NULL,
  `online` int(11) NOT NULL,
  `street` varchar(64) NOT NULL,
  `plz` varchar(16) NOT NULL,
  `city` varchar(64) NOT NULL,
  `land` varchar(16) NOT NULL,
  `hasNewPassword` varchar(1) NOT NULL,
  `secret` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `kunde`
--

INSERT INTO `kunde` (`UserID`, `vorname`, `nachname`, `email`, `password`, `lastLogin`, `online`, `street`, `plz`, `city`, `land`, `hasNewPassword`, `secret`) VALUES
(1, 'Marios', 'Tzialidis', 'test@test.de', 'c6ee9e33cf5c6715a1d148fd73f7318884b41adcb916021e2bc0e800a5c5dd97f5142178f6ae88c8fdd98e1afb0ce4c8d2c54b5f37b30b7da1997bb33b0b8a31', 'Wed, 14 Dec 2022 17:24:03 +0100', 0, 'Hausstrasse 12', '72072', 'Tübingen', 'Deutschland', '1', ''),
(2, 'Kevin', 'Koch', 'kevin@koch.de', 'c84dd703', 'Tue, 15 Nov 2022 13:04:34 +0100', 0, 'Hausstrasse 2', '72074', 'Tübingen', 'Deutschland', '0', ''),
(3, 'Kevin', 'Koch', 'Kevinkoch1997@yahoo.de', '353116a1', 'Tue, 20 Dec 2022 14:14:02 +0100', 0, 'Freudenstädterstraße 50', '72250', 'Freudenstadt', 'Deutschland', '0', 'IVPAR37HOKQYGBSJ'),
(4, 'Kevin', 'Koch', 'Kevinkoch1997@yahoo.de', '57d07d07', 'Tue, 20 Dec 2022 14:26:06 +0100', 0, 'Freudenstädterstr 50', '72250', 'FDS', 'Deutschland', '0', 'TH7MFWFMDYLRH5JY'),
(5, 'Karl', 'Kohler', 'Kevinkoch1997@gmail.com', '0044f4acc463f69d72f8632fc07751139ef0a37cfc67c772740aa32f3da4078cbc3275a81f155a6ff5305a7bcd736da6470491fedfdb718f1f969da3f5c58cdb', 'Sat, 07 Jan 2023 01:38:32 +0100', 0, 'Hauptstraße 50', '72250', 'Stuttgart', 'Ungarn', '1', 'XBORGT7CQCLTLIYQ');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `newsletter`
--

CREATE TABLE `newsletter` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `newsletter`
--

INSERT INTO `newsletter` (`id`, `email`, `time`) VALUES
(1, 'test@test.de', 'Wed, 14 Dec 2022 19:15:33 +0100');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `payment`
--

CREATE TABLE `payment` (
  `paymentID` int(64) NOT NULL,
  `paymentMethod` varchar(128) NOT NULL DEFAULT 'Credit Card',
  `nameOnCard` varchar(128) NOT NULL,
  `creditNumber` varchar(64) NOT NULL,
  `expirationDate` varchar(10) NOT NULL,
  `cvv` varchar(4) NOT NULL,
  `BestellID` int(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `payment`
--

INSERT INTO `payment` (`paymentID`, `paymentMethod`, `nameOnCard`, `creditNumber`, `expirationDate`, `cvv`, `BestellID`) VALUES
(1, 'Credit Card', 'Kohler', '123456987546132321654987', '12.12.24', '3213', 49);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `warenkorb`
--

CREATE TABLE `warenkorb` (
  `WarenkorbID` int(8) NOT NULL,
  `ArtikelID` int(8) NOT NULL,
  `UserID` int(8) NOT NULL,
  `Menge` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`ArtikelID`),
  ADD UNIQUE KEY `artikelNummer` (`artikelNummer`);

--
-- Indizes für die Tabelle `bestellitem`
--
ALTER TABLE `bestellitem`
  ADD PRIMARY KEY (`BestellItemID`);

--
-- Indizes für die Tabelle `bestellung`
--
ALTER TABLE `bestellung`
  ADD PRIMARY KEY (`BestellID`);

--
-- Indizes für die Tabelle `discount`
--
ALTER TABLE `discount`
  ADD PRIMARY KEY (`discountID`);

--
-- Indizes für die Tabelle `kunde`
--
ALTER TABLE `kunde`
  ADD PRIMARY KEY (`UserID`);

--
-- Indizes für die Tabelle `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indizes für die Tabelle `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`paymentID`);

--
-- Indizes für die Tabelle `warenkorb`
--
ALTER TABLE `warenkorb`
  ADD PRIMARY KEY (`WarenkorbID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `artikel`
--
ALTER TABLE `artikel`
  MODIFY `ArtikelID` int(64) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT für Tabelle `bestellitem`
--
ALTER TABLE `bestellitem`
  MODIFY `BestellItemID` int(64) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT für Tabelle `bestellung`
--
ALTER TABLE `bestellung`
  MODIFY `BestellID` int(64) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT für Tabelle `discount`
--
ALTER TABLE `discount`
  MODIFY `discountID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT für Tabelle `kunde`
--
ALTER TABLE `kunde`
  MODIFY `UserID` int(64) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT für Tabelle `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT für Tabelle `payment`
--
ALTER TABLE `payment`
  MODIFY `paymentID` int(64) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT für Tabelle `warenkorb`
--
ALTER TABLE `warenkorb`
  MODIFY `WarenkorbID` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;
COMMIT;
