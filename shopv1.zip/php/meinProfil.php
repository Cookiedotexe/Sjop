<?php 
    session_start();
    if(isset($_SESSION['UserID']))
    {
        $userID = (int) $_SESSION['UserID'];
    }
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mein Profil</title>

    <!--Header Import (css-Links)-->
    <?php include 'imports/headerImport.php';?>
</head>
<body>
    <?php include 'imports/navImport.php';?>


    


    <!-- <div class="container w-100" id="display"> -->
    <?php 

        include 'imports/dbSettings.php';

        $bestellung ="SELECT * FROM Bestellung WHERE UserID = ' " . $userID . " ' ";
        foreach($conn->query($bestellung) as $row){
            
            $sql = "SELECT *
            FROM kunde, bestellitem AS BI ,bestellung AS B,Artikel AS AR 
            WHERE kunde.UserID = ' " . $userID . " '
            AND B.BestellID = ".$row['BestellID']."
            AND B.BestellID = bi.bestellid 
            AND B.UserID = Kunde.UserID
            AND BI.ArtikelID=AR.ArtikelID";

            echo '
            <section style="background-color: #eee;">
                <div class="container py-5 w-100">                                                                          
                    <div class="order">
                        <div class="d-flex justify-content-between">
                            <span>BestellID.: '.$row['BestellID'].'</span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Gesamtpreis.: '.$row['Gesamtpreis'].'</span>
                        </div>
                    </div>
                    <div class="item9">
                            
                            ';


            foreach($conn->query($sql) as $row2){
                echo'
                
                    
                        
                        <div class="item8" >
                            
                                
                                
                                <div class="d-flex justify-content-between">
                                    <span>'.$row2['name'].'</span><span>ArtikelID.: '.$row2['ArtikelID'].'</span>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <span>Menge.:</span><span> '.$row2['Menge'].'</span></span>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <span>Artikel</span><span>'.$row2['name'].'</span>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <span>Preis mit Rabatt</span><span> '.$row2['PositionsPreis'].' €</span>
                                </div>
                                <div class="d-flex justify-content-between total font-weight-bold mt-4">
                                <span>Preis/ Stück</span><span>'.$row2['preis'].' €</span>
                                </div>
                            
                        
                    </div>
                    
                
                ';
            }
            echo ' 
                </div> 
            
            <div class="d-flex justify-content-between total font-weight-bold mt-4">
                 <form action="erneutbestellen.php" method="post">
                    

                    <input type="hidden" id="BestellID" name="BestellID" value="'.$row['BestellID'].'">
                
                    <span class="centered"><input type="submit" value="Erneut Bestellen"></span>
                </form>
            </div>
        </section>
                ';
        }

        
    
    ?>
    <!--</div>-->

    <?php include "imports/newsletterImport.php"; ?>

    <div class="container3">
        <footer class="py-3 my-4">
            <ul class="nav justify-content-center border-bottom pb-3 mb-3">
                <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Home</a></li>
                <li class="nav-item"><a href="php/#" class="nav-link px-2 text-muted">Alle Artikel</a></li>
                <li class="nav-item"><a href="php/#" class="nav-link px-2 text-muted">Mein Profil</a></li>
                <li class="nav-item"><a href="php/#" class="nav-link px-2 text-muted">Impressum</a></li>
                <li class="nav-item"><a href="php/#" class="nav-link px-2 text-muted">Datenschutz</a></li>
            </ul>
            <p class="text-center text-muted"><?php echo date("Y"); ?> © Marios Tzialidis, Kevin Koch</p>
        </footer>
    </div>

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>  
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>

        $(document).ready(function(){
            $("#search").keyup(function(){
                var input = $(this).val();

                console.log(input);

                if(input != ""){
                    $.ajax({
                        url: "ajax/searchAjax.php",
                        method: "POST",
                        data: {
                                search: input
                            },

                        sucess:function(data){
                            $("#display").html(data);
                        }
                    });
                }
            })
        });

    </script>
    <script>
        var input = document.getElementById('search').value;
        var display = document.getElementById('display');

        function search(){

            var searchInput = document.getElementById('search').value;

            if(search != ""){

                $.ajax({
                    url : "ajax/searchAjax.php",
                    method : "POST",
                    data:{
                        search: searchInput
                    },
                    success: function(data){
                        $("#display").html(data);
                    }
                })
            }
        }
    </script>

    <?php include 'imports/scriptImport.php';?>
    
</body>
</html>



<!--
    - Warenkorb Widget in der Nav-Bar
    - Warenkorb Badge
    - Input Field mit Submit Button und Form
    - Ajax mit der Badge
    - Datenbank für Warenkorb erstellen
 -->