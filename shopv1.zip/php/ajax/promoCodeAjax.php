<?php
    $promoCode="";

    $codeValueDatabase="";

    if(isset($_POST['promoCode'])){
        $promoCode = $_POST['promoCode'];

        $con = MySQLi_connect(

            'localhost',

            'root',

            '',

            'getraenkeHandel2'

        );

        if (MySQLi_connect_errno()) {

            echo "Failed to connect to MySQL: " . MySQLi_connect_error();

        }

        try{

            include '../imports/dbSettings.php';

            $sql = "SELECT * FROM discount WHERE discountName = '".$promoCode."' LIMIT 1";

            $stmt = MySQLi_query($con, $sql);

            if(mysqli_num_rows($stmt) === 0){
                    echo "
                        <div style='height: auto; width: 100%;'>
                            <h3 class='text-danger text-center mt-3'>&#10060; Bitte gib einen gültigen Code ein!</h3>
                        </div>
                    ";
            }else {

                include "../imports/dbSettings.php";
                                
                foreach($conn-> query($sql) as $row){

                    $codeValueDatabase = $row['discountValue'];     //Heisst das "discountValue" in der Datenbank? //
                }
                echo "

                        <div style='height: auto; width: 100%;'>
                            <h3 class='text-success text-center mt-3'>Gutschein-Code ist aktiviert! &#10004;</h3>
                            <input type='hidden' value='".$codeValueDatabase."'>
                        </div>
                ";
            }
        }catch(Exception $e){

            echo "Fehler: ".$e;

        }
    }else{
        echo "Fehler bei der Übergabe des Promo Codes";
    }
?>