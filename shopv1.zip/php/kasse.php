<?php 
    session_start();
    if(isset($_SESSION['UserID']))
    {
        $userID = (int) $_SESSION['UserID'];
    }
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kasse</title>

    <!--Header Import (css-Links)-->
    <?php include 'imports/headerImport.php';?>
</head>
<body>
    <?php include 'imports/navImport.php';?>


    <section class="searchArea">
        <h1 class="homeH1">Kasse</h1>
        
    </section>


    <div class="display">
    <?php 

        include 'imports/dbSettings.php';

        $sql = "SELECT * 
                FROM artikel AS a
                LEFT JOIN warenkorb as w ON a.artikelID = w.artikelID
                where userID='" . $_SESSION['UserID'] ."'";

        foreach($conn->query($sql) as $row){
            if($row['Menge'] >= 5)
            {
            $rabattanz="10 %";
            $gpmitRabatt=round((($row['preis'] * $row['Menge']) * 0.9),2);
            }
            
            if($row['Menge'] < 5 )
            {
            $rabattanz="0 %";
            $gpmitRabatt=round(($row['preis'] * $row['Menge']),2);
            }

            if($row['Menge'] >= 10)
            {
            $rabattanz="20 %";   
            $gpmitRabatt=round((($row['preis'] * $row['Menge']) * 0.8),2);
            }
            echo '
            <section style="background-color: #eee;">
                <div class="container py-5">
                    <div class="row justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-4">
                        <div class="card text-black">
                        <img style="width:40%" src="'.$row['path'].'"
                            class="card-img-top" alt="'.$row['name'].'" />
                        <div class="card-body">
                            <div class="text-center">
                            <p class="text-muted mb-4">'.$row['name'].'</p>
                            </div>
                            <div>
                            <div class="d-flex justify-content-between">
                                <span>'.$row['name'].'</span><span>Art.Nr.: '.$row['artikelNummer'].'</span>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span>Füllmenge</span><span>'.$row['inhalt'].' Liter</span>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span>On Stock</span><span> '.$row['onStock'].' Stück</span>
                            </div>
                            </div>
                            <div class="d-flex justify-content-between total font-weight-bold mt-4">
                            <span>Preis/ Stück</span><span>'.$row['preis'].' €</span>
                            </div>
                            <div class="d-flex justify-content-between total font-weight-bold mt-4">
                            <span>Rabatt:</span><span>'.$rabattanz.' </span>
                            </div>
                            <div class="d-flex justify-content-between total font-weight-bold mt-4">
                            <span>Gesamtpreis</span><span class="sum2">'.$gpmitRabatt.' </span>
                            </div>
                            <div class="d-flex justify-content-between total font-weight-bold mt-4">
                            <span>Menge: '.$row['Menge'].'</span>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
            </section>
            ';
        }//hidden Value evtl. unsicher
    
   

    ?> 

    <div class="card p-2 redeemForm">
        <div class="input-group">
            <input id="promoCode" name="promoCode" type="search" class="form-control" placeholder="Promo code">
            <button id="redeemButton" class="btn btn-secondary" onclick="checkPromoCode()">Redeem</button>
        </div>
    </div>

    <div style="width: 100%">
        <h3 id="sumText"></h3>
    </div>
    
    <form action="bestellen.php" method="POST">
        <div  class="centered">
            <span></span>
            <div id="successDiv" class="sucessDiv" style="background-color: white; text-align: center;"></div>
            
            <div class="row g-3">
            <div class="col-sm-6">
              <label for="firstName" class="form-label">Vorname</label>
              <input type="text" class="form-control" name="firstName" id="firstName" placeholder="" value="" required="">
              <div class="invalid-feedback">
                Valid first name is required.
              </div>
            </div>

            <div class="col-sm-6">
              <label for="lastName" class="form-label">Nachname</label>
              <input type="text" class="form-control" name="lastName" id="lastName" placeholder="" value="" required="">
              <div class="invalid-feedback">
                Valid last name is required.
              </div>
            </div>

            <div class="col-12">
              <label for="address" class="form-label">Straße</label>
              <input type="text" class="form-control" name="strasse" id="strasse" placeholder="Hauptstr. 1" required="">
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
            </div>
            <div class="col-12">
              <label for="address" class="form-label">PLZ</label>
              <input type="text" class="form-control" name="plz" id="plz" placeholder="70180" required="">
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
            </div>
            <div class="col-12">
              <label for="address" class="form-label">Stadt</label>
              <input type="text" class="form-control" name="city" id="city" placeholder="Stuttgart" required="">
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
            </div>
            <div class="col-12">
              <label for="address" class="form-label">Land</label>
              <input type="text" class="form-control" name="state" id="state" placeholder="Deutschland" required="">
              <div class="invalid-feedback">
                Please enter your shipping address.
              </div>
            </div>


          <h4 class="mb-3">Payment</h4>       

          <div class="row gy-3">
            <div class="col-md-6">
              <label for="cc-name" class="form-label">Name on card</label>
              <input type="text" class="form-control" name="ccname" id="ccname" placeholder="" required="">
              <small class="text-muted">Full name as displayed on card</small>
              <div class="invalid-feedback">
                Name on card is required
              </div>
            </div>

            <div class="col-md-6">
              <label for="cc-number" class="form-label">Credit card number</label>
              <input type="text" class="form-control" name="ccnumber" id="ccnumber" placeholder="" required="">
              <div class="invalid-feedback">
                Credit card number is required
              </div>
            </div>

            <div class="col-md-3">
              <label for="cc-expiration" class="form-label">Expiration</label>
              <input type="text" class="form-control" name="ccexpiration" id="ccexpiration" placeholder="" required="">
              <div class="invalid-feedback">
                Expiration date required
              </div>
            </div>

            <div class="col-md-3">
              <label for="cc-cvv" class="form-label">CVV</label>
              <input type="text" class="form-control" name="cvv" id="cvv" placeholder="" required="">
              <div class="invalid-feedback">
                Security code required
              </div>
            </div>
          </div>

          <hr class="my-4">


            <select name="Versandart">
                <option value="DPD">DPD: 6 €</option>
                <option value="DHL">DHL: 15 €</option>
                <option value="DHL Express">DHL Express: 48 €</option>
            </select> 
            
            <span><input type="submit" value="Bestellen"></span>
            <span></span>
         </div>
    </form>
    </div>

    <?php include "imports/newsletterImport.php"; ?>

    <div class="container3">
        <footer class="py-3 my-4">
            <ul class="nav justify-content-center border-bottom pb-3 mb-3">
                <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Home</a></li>
                <li class="nav-item"><a href="php/#" class="nav-link px-2 text-muted">Alle Artikel</a></li>
                <li class="nav-item"><a href="php/#" class="nav-link px-2 text-muted">Mein Profil</a></li>
                <li class="nav-item"><a href="php/#" class="nav-link px-2 text-muted">Impressum</a></li>
                <li class="nav-item"><a href="php/#" class="nav-link px-2 text-muted">Datenschutz</a></li>
            </ul>
            <p class="text-center text-muted"><?php echo date("Y"); ?> © Marios Tzialidis, Kevin Koch</p>
        </footer>
    </div>

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>  
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <?php include 'imports/scriptImport.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    

    <script>

        var elements = document.querySelectorAll('.sum2');
        var total = 0;

        for (var i = 0; i < elements.length; i++) {
            var value = elements[i].textContent;
            if(!isNaN(value))
                total += parseFloat(elements[i].textContent);
        }

       
        var sumText = document.getElementById('sumText');
        sumText.textContent = "Die Gesamtsumme *exkl Versandkosten: " + total + " €";
        



        let redeemButton = document.getElementById('redeemButton');

        redeemButton.addEventListener('click', checkPromoCode());

        function checkPromoCode() {

            var promoCodeValue = document.getElementById('promoCode').value;
            var successDiv = document.getElementById('successDiv');

            console.log(promoCodeValue);
        
            if(promoCodeValue == ""){
                successDiv.textContent = "Bitte gib einen gültigen Code ein!";
            }else {
                successDiv.textContent="";
                $.ajax({
                    url : "ajax/promoCodeAjax.php",
                    method : "POST",
                    data:{
                        promoCode: promoCodeValue
                    },
                    success: function(data){
                        $("#successDiv").html(data);

                        //Wenn das erfolgreich war, dann wird der Gesamtpreis angepasst
                        var codeValueDatabase2 = document.getElementById('codeValueDatabase').value;                                             

                        if(codeValueDatabase2 != ""){
                            total = total * (1 - codeValueDatabase2);
                        }

                        console.log('Value aus der Datenbank: ' + codeValueDatabase2);

                        var sumText = document.getElementById('sumText');
                        sumText.textContent = "Die Gesamtsumme *exkl Versandkosten: " + total + " €";
                    }})
               
            }
        }

    </script>
    
</body>
</html>
